# SoraChat

- `www/` : kode web (HTML/CSS/JS) + `firebase-config.js`
- `firebase/` : Security Rules dan panduan setup Firebase
- `.github/workflows/build-apk.yml` : build APK otomatis di GitHub

## Build APK
1. Push repo ini ke GitHub (branch `main`).
2. Buka tab **Actions** -> **Build APK** -> **Run workflow** (juga jalan otomatis tiap push).
3. Setelah hijau, buka run tersebut -> bagian **Artifacts** -> unduh `SoraChat-debug-apk` (ZIP berisi `app-debug.apk`).
4. Ekstrak, lalu install APK di HP (izinkan "install dari sumber tidak dikenal").

## Catatan
- APK ini versi debug (ditandatangani kunci debug), cukup untuk dipakai sendiri dan dibagikan ke teman.
- Di Firebase, domain `localhost` harus ada di Authentication -> Settings -> Authorized domains (biasanya sudah ada).
- Hosting web tetap bisa lewat Netlify: publish directory `www`.
